package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BooksService {
	
	@Autowired
	BooksRepository booksRepository;
	
	public Books getBooksById(int id) {
		return booksRepository.findById(id).get();
	}
	
	public Books saveOrUpdate(Books books) {
		
		int newPrice = (books.getPrice()) + 10000;
		books.setPrice(newPrice);
		return booksRepository.save(books);
	}
	
	/*
	public void Update(Books books, int id) {
		booksRepository.save(books);
	}*/
	
	public void delete(int id)
	{
	booksRepository.deleteById(id);
	}
	
	
	public List<Books> getAllBooks()
	{
	List<Books> books = new ArrayList<Books>(); booksRepository.findAll().forEach(books1 -> books.add(books1)); return books;
	}

}

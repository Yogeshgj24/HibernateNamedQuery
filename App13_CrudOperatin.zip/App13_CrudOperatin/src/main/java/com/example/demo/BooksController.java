package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BooksController {
	
	@Autowired
	BooksService booksService;
	
	@Autowired
	BooksRepository booksRepository;
	
	@GetMapping("/book/{bookid}")
	private Books GetBooks(@PathVariable("bookid") int bookid) {
		return booksService.getBooksById(bookid);
	}
	
	@PostMapping("/books")
	private int saveBook(@RequestBody Books books) {
		 booksService.saveOrUpdate(books);
		 return books.getBookId();
	}
	
	@PostMapping("/booksrepo")
	private int saveBook1(@RequestBody Books books) {
		 //booksService.saveOrUpdate(books);
		booksRepository.save(books);
		 return books.getBookId();
	}
	
	/*
	@PutMapping("/update1")
	private Books Update1(@RequestBody Books  books) {
		 booksService.Update( books, books.getBookId());
		 return books;
	} */
	
	@PutMapping("/update2")
	private Books Update2(@RequestBody Books books) {
		booksService.saveOrUpdate(books);
		return books;
	}
	
	
	@DeleteMapping("/delete1/{bookId}")
	private void DeleteBooks(@PathVariable("bookId") int bookId ) {
		booksService.delete(bookId);
	}
	
	
	@DeleteMapping("/delete2/{bookId}")
	private int DeleteBooks1(@PathVariable("bookId") int bookId ) {
		booksService.delete(bookId);
		return bookId;
	}
	
	@GetMapping("/book")
	private List<Books> getAllBooks()
	{
	return booksService.getAllBooks();
	}

}


/*
	{
    "bookId" : "02",
    "bookname" : "Core Java II",
    "author" : "XAbZ",
    "price" : "700"
}


*/

package org;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedQueries(
		{
			@NamedQuery(
					name = "findEmployeeByName",
					query = "from employeeinfo e where e.emp_name = :name"
					)
		}
		)


@Entity
@Table(name = "employeeinfo")
public class MyEntity {
	
	@Id
	@Column(name = "Emp_id")
	private int EmpId;
	
	@Column(name = "Emp_Name")
	private String EmpName;
	
	@Column(name = "Emp_sal")
	private int EmpSalary;

	
	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public int getEmpSalary() {
		return EmpSalary;
	}

	public void setEmpSalary(int empSalary) {
		EmpSalary = empSalary;
	}

	@Override
	public String toString() {
		return "MyEntity [EmpId=" + EmpId + ", EmpName=" + EmpName + ", EmpSalary=" + EmpSalary + "]";
	}

	
	
	
	
	
	
}
